# LOOPAROO — Website (v2)

Professionelle One-Page-Website für **LOOPAROO GmbH** (Mehrweg-Versandtaschen, rPET, EU-PPWR-konform).

Reines HTML/CSS/JS ohne Build-Schritt — direkt per **GitHub Pages** deploybar. Alle Grafiken sind selbst gestaltete Vektor-Illustrationen (SVG), keine externen Bilddateien nötig — dadurch lädt die Seite schnell und es gibt keine toten Bildlinks.

## Was ist neu gegenüber v1

- **Interaktiver Ersparnis-Rechner** — Slider für Pakete/Monat, live berechnete Kosten Einweg vs. LOOPAROO
- **Interaktive Loop-Erklärung** — klickbarer 5-Schritte-Stepper mit animiertem Fortschrittsring
- **Größen-Umschalter** (S/L) am Produkt mit live aktualisierter Spec-Tabelle
- **Wettbewerbsvergleichs-Tabelle** (LOOPAROO vs. RePack, Hey Circle, Hipli, LivingPackets)
- **FAQ-Akkordeon** und Mini-FAQ im Endkund:innen-Bereich
- Aktive Navigations-Hervorhebung beim Scrollen, Kategorie-Marquee, Vertrauens-Signale im Hero
- Feinere Design-Sprache: Schatten-/Radius-Skala, Hover-Mikrointeraktionen, konsistente Card-Komponenten

## Struktur

```
looparoo-website/
├── index.html         Alle Inhalte/Sektionen der One-Page-Website
├── css/styles.css      Design-System (Farben, Typografie, Layout, Responsive)
├── js/main.js           Nav, Scroll-Reveal, Zähler, Tabs, Stepper, Rechner, Formular
└── README.md
```

## Sektionen

1. Hero mit Live-Statistiken & animierter Loop-Grafik
2. Branchen-Marquee
3. Problem (Marktzahlen)
4. Produkt (S/L-Umschalter, Spec-Tabelle)
5. „So funktioniert der Loop" (interaktiver Stepper)
6. Ersparnis-Rechner (interaktiv)
7. Für Endkund:innen (inkl. Mini-FAQ)
8. Für Partner-Unternehmen (Preistabelle, Pilotprojekt)
9. Wettbewerbsvergleich
10. Markt & Roadmap
11. Team
12. FAQ
13. Kontakt-/Partneranfrage-Formular

## Lokal starten

```bash
npx serve .
```
oder `index.html` direkt im Browser öffnen.

## Auf GitHub Pages veröffentlichen

1. Repo-Inhalt (ohne den Ordner `looparoo-website` selbst — nur seinen Inhalt) ins Repo-Root hochladen
2. **Settings → Pages** → Branch `main`, Ordner `/ (root)` → Save
3. Seite ist unter `https://<username>.github.io/<repo>/` erreichbar

## Anpassungen

- **Rechner-Annahmen** (Einwegkosten, LOOPAROO-Kosten pro Versand) in `js/main.js` unter `updateCalc()` anpassbar
- **Farben/Schriften** zentral über CSS-Variablen in `css/styles.css` (`:root`)
- **Formular an echtes Backend anbinden:** `submit`-Handler in `js/main.js` durch `fetch()`-Aufruf ersetzen (z. B. Formspree)

## Hinweis zu Bildmaterial

Es wurden keine echten Produktfotos verwendet, da keine lizenzfreien/eigenen Fotos vorlagen. Stattdessen wurden alle Produkt-, Illustrations- und Icon-Grafiken als eigenständige SVG-Vektorgrafiken im Markenlook gestaltet. Sobald echte Produktfotos vorliegen, können sie problemlos an den markierten Stellen (`.hero__visual`, `.product-panel__visual`) ergänzt werden.
